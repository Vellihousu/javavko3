package main;

public class Zoo {
    private String zooName;

    public Zoo(String zooName) {
        this.zooName = zooName;
    }

    public void setName(String zooName) {
        this.zooName = zooName;
    }

    public String getName() {
        return zooName;
    }

}

